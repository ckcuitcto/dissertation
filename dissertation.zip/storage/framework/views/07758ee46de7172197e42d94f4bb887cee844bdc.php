<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-laptop"></i> Tổng điểm cá nhân</h1>
                <p>Trường Đại học Công nghệ Sài Gòn</p>
            </div>
            <ul class="app-breadcrumb breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
                <li class="breadcrumb-item">Tổng điểm cá nhân</li>
            </ul>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <h3 class="tile-title">Lưu ý</h3>
                    <div class="tile-body">
                        <div><i class="fa fa-file-text-o" aria-hidden="true"></i> Điểm cá nhân, Điểm lớp và Điểm khoa là
                            điểm đánh giá chưa tính điểm học tập
                        </div>
                        <div><i class="fa fa-file-text-o" aria-hidden="true"></i> Điểm tổng là điểm sau khi P.CTSV kiểm
                            duyệt đã bao gồm điểm học tập
                        </div>
                        <div><i class="fa fa-file-text-o" aria-hidden="true"></i> Xếp loại và Điểm tổng nếu có giá trị
                            là "_" thì đang đợi bổ sung điểm học tập
                        </div>

                    </div>
                    <div class="title-body" align="right">
                        <div>Họ và tên: <?php echo e($user->name); ?></div>
                        <div>Lớp: <?php echo e(isset($user->Student->Classes->name) ? $user->Student->Classes->name : ""); ?></div>
                        <div>MSSV: <?php echo e($user->id); ?></div>
                        <div>Khoa: <?php echo e(isset($user->Faculty->name) ? $user->Faculty->name : ""); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <table class="table table-hover table-bordered">
                        <tbody>
                        <tr>
                            <td rowspan="2">STT</td>
                            <td rowspan="2">Học Kỳ</td>
                            <td rowspan="2">Năm Học</td>
                            <td colspan="4">Điểm</td>
                            <td rowspan="2">Xếp Loại</td>
                            <td rowspan="2">Tình Trạng</td>
                            <td rowspan="2">Tác Vụ</td>
                        </tr>
                        <tr>
                            <td>Cá Nhân</td>
                            <td>Lớp</td>
                            <td>Khoa</td>
                            <td>Tổng</td>
                        </tr>
                        <?php $__currentLoopData = $evaluationForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $evaluationForm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($evaluationForm->Semester->term); ?></td>
                                <td><?php echo e($evaluationForm->Semester->year_from . " - " . $evaluationForm->Semester->year_to); ?></td>
                                <td>x</td>
                                <td>x</td>
                                <td>x</td>
                                <td>x</td>
                                <td>Trung Bình</td>
                                <td>Hoàn Thành</td>
                                <td>
                                    
                                    <a
                                        href="<?php echo e(route('evaluation-form-show',$evaluationForm->id)); ?>"
                                    >
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </a>
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>