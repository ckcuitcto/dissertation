<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-file-text-o"></i> Phiếu đánh giá điểm rèn luyện</h1>
                <p>Trường Đại học Công nghệ Sài Gòn</p>
            </div>
            <ul class="app-breadcrumb breadcrumb side">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
                <li class="breadcrumb-item">Phiếu đánh giá điểm rèn luyện</li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="tile-body">
                        <div class="tile user-settings">
                            <h4 class="line-head">Thông tin sinh viên</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div>- Họ và tên: <?php echo e($evaluationForm->Student->User->name); ?></div>
                                    <div>- Lớp: <?php echo e(isset($evaluationForm->Student->Classes->name) ? $evaluationForm->Student->Classes->name : ""); ?></div>
                                    <div>- MSSV: <?php echo e(isset($evaluationForm->Student->user_id) ? $evaluationForm->Student->user_id : ""); ?></div>
                                </div>
                                <div class="col-md-6">
                                    <div>- Khoa: <?php echo e(isset($evaluationForm->Student->Classes->Faculty->name) ? $evaluationForm->Student->Classes->Faculty->name : ""); ?></div>
                                    <div>- Niên
                                        khóa: <?php echo e($evaluationForm->Student->academic_year_from . " - " . $evaluationForm->Student->academic_year_to); ?></div>
                                </div>
                            </div>
                        </div>
                        <form name="evaluation-form" id="evaluation-form"
                              action="<?php echo e(route('evaluation-form-update',$evaluationForm->id)); ?>" method="post"
                              enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            
                            <table class="table table-hover table-bordered">
                                <tbody>
                                <tr>
                                    <td><strong>Nội dung đánh giá</strong></td>
                                    <td><strong>Thang điểm</strong></td>
                                    <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><b> <?php echo e($role->display_name); ?></b></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <tr class="text-center">
                                    <td>(1)</td>
                                    <td>(2)</td>
                                    <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>(<?php echo e($key +3); ?>)</td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php $__currentLoopData = $evaluationCriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $valueLevel1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="<?php echo e(2 + count($listRoleCanMark)); ?>">
                                            <b> <?php echo e($valueLevel1->content); ?></b></td>
                                    </tr>
                                    <?php $__currentLoopData = $valueLevel1->Child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueLevel2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($valueLevel2->detail): ?>
                                                <td class='detail-evaluation-form'>
                                                    <?php echo e($valueLevel2->content); ?>

                                                    <?php if(isset($valueLevel2->proof)): ?>
                                                        <?php $name= "proof".$valueLevel2->id; ?>
                                                        <input type="file" class="proof" id="<?php echo e($valueLevel2->id); ?>"
                                                               name="<?php echo e($name); ?>" multiple>
                                                    <?php endif; ?>
                                                    <?php echo \App\Http\Controllers\Evaluation\EvaluationFormController::handleDetail($valueLevel2->detail); ?>

                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <?php echo e($valueLevel2->content); ?>

                                                    <?php if(isset($valueLevel2->proof)): ?>
                                                        <?php $name= "proof".$valueLevel2->id; ?>
                                                        <input type="file" class="proof" id="<?php echo e($valueLevel2->id); ?>"
                                                               name="<?php echo e($name); ?>" multiple>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e(isset($valueLevel2->mark_range_display) ? $valueLevel2->mark_range_display : ""); ?>

                                            </td>
                                            <?php if(isset($valueLevel2->mark_range_display)): ?>
                                                <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($role->name == $user->Role->name): ?>
                                                        <?php $name= "score".$valueLevel2->id; ?>
                                                        <td><input required type="number" name="<?php echo e($name); ?>"
                                                                   value="<?php echo e(isset($evaluationResults[$valueLevel2->id]['marker_score']) ? $evaluationResults[$valueLevel2->id]['marker_score'] : 0); ?>"
                                                                   min="<?php echo e($valueLevel2->mark_range_from); ?>"
                                                                   max="<?php echo e($valueLevel2->mark_range_to); ?>"
                                                                   id="<?php echo e("child_".$valueLevel1->id); ?>"
                                                                   <?php echo e(($valueLevel2->step_html) ? "step=$valueLevel2->step_html" : ""); ?>

                                                                   class="form-control <?php echo e($role->name); ?>">
                                                        </td>
                                                    <?php else: ?>
                                                        <td><input type="number" disabled="true"
                                                                   class="form-control <?php echo e($role->name); ?>"></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tr>
                                        <?php $__currentLoopData = $valueLevel2->Child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueLevel3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if($valueLevel3->detail): ?>
                                                    <td class='detail-evaluation-form'>
                                                        <?php echo e($valueLevel3->content); ?>

                                                        <?php if(isset($valueLevel3->proof)): ?>
                                                            <?php $name= "proof".$valueLevel3->id; ?>
                                                            <input type="file" class="proof" id="<?php echo e($valueLevel3->id); ?>"
                                                                   name="<?php echo e($name); ?>" multiple>
                                                        <?php endif; ?>
                                                        <?php echo \App\Http\Controllers\Evaluation\EvaluationFormController::handleDetail($valueLevel3->detail); ?>

                                                    </td>
                                                <?php else: ?>
                                                    <td>
                                                        <?php echo e($valueLevel3->content); ?>

                                                        <?php if(isset($valueLevel3->proof)): ?>
                                                            <?php $name= "proof".$valueLevel3->id; ?>
                                                            <input type="file" class="proof" id="<?php echo e($valueLevel3->id); ?> "
                                                                   name="<?php echo e($name); ?>" multiple>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td><?php echo e(isset($valueLevel3->mark_range_display) ? $valueLevel3->mark_range_display : ""); ?></td>
                                                <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($role->name == $user->Role->name): ?>
                                                        <?php $name= "score".$valueLevel3->id; ?>
                                                        <td><input required type="number" name="<?php echo e($name); ?>"
                                                                   value="<?php echo e(isset($evaluationResults[$valueLevel3->id]['marker_score']) ? $evaluationResults[$valueLevel3->id]['marker_score'] : 0); ?>"
                                                                   min="<?php echo e($valueLevel3->mark_range_from); ?>"
                                                                   max="<?php echo e($valueLevel3->mark_range_to); ?>"
                                                                   id="<?php echo e("child_".$valueLevel1->id); ?>"
                                                                   <?php echo e(($valueLevel3->step_html) ? "step=$valueLevel3->step_html" : ""); ?>

                                                                   class="form-control  <?php echo e($role->name); ?>">
                                                        </td>
                                                    <?php else: ?>
                                                        <td><input type="number" disabled="true"
                                                                   class="form-control <?php echo e($role->name); ?>"></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="2" class="text-center">
                                            <b>Tổng <?php echo e(\App\Helpers\Convert::numberToRomanRepresentation($key +1)); ?>.
                                                (Tối đa <?php echo e($valueLevel1->mark_range_to); ?> điểm) </b></td>
                                        <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($role->name == $user->Role->name): ?>
                                                <?php $name= "score".$valueLevel1->id; ?>
                                                <td>
                                                    <input type="number"
                                                           name=<?php echo e($name); ?>

                                                                   required
                                                           id="<?php echo e("total_".$valueLevel1->id); ?>"
                                                           value="<?php echo e(isset($evaluationResults[$valueLevel1->id]['marker_score']) ? $evaluationResults[$valueLevel1->id]['marker_score'] : 0); ?>"
                                                           min="<?php echo e($valueLevel1->mark_range_from); ?>"
                                                           max="<?php echo e($valueLevel1->mark_range_to); ?>"
                                                           topic="totalTopic"
                                                           readonly
                                                           class="form-control <?php echo e($role->name); ?>">
                                                </td>
                                            <?php else: ?>
                                                <td><input type="number" disabled="true"
                                                           class="form-control <?php echo e($role->name); ?>"></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td>Tổng cộng</td>
                                    <td>0 - 100</td>
                                    <?php $__currentLoopData = $listRoleCanMark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($role->name == $user->Role->name): ?>
                                            <td><input type="text"
                                                       class="form-control <?php echo e($role->name); ?>"
                                                       required
                                                       value="<?php echo e(isset($evaluationForm->total) ? $evaluationForm->total : "0"); ?>"
                                                       name="totalScoreOfForm"
                                                       id="totalScoreOfForm"
                                                       readonly
                                                >
                                            </td>
                                        <?php else: ?>
                                            <td><input type="number" disabled="true"
                                                       class="form-control <?php echo e($role->name); ?>"></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <tr>
                                    <td>Xếp loại</td>
                                    <td colspan="<?php echo e(count($listRoleCanMark)); ?>" style="background-color:gray"></td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>
                            <div align="right">
                                <button class="btn btn-primary" type="submit">Lưu</button>
                                <button class="btn btn-secondary" type="reset">Hủy</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-javascript'); ?>
    <script type="text/javascript" src="<?php echo e(asset('template/js/plugins/jquery.dataTables.min.js')); ?> "></script>
    <script type="text/javascript" src="<?php echo e(asset('template/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js//evaluationForm.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            
            

            $('.proof').change(function (e) {
                var urlCheckFile = "<?php echo e(route('evaluation-form-upload')); ?>";
                var formData = new FormData();
                var fileUpload = $(this);
                var countFile = fileUpload[0].files.length;
                for (var x = 0; x < countFile; x++) {
                    file = fileUpload[0].files[x];
                    formData.append("fileUpload[]", file);
                }
//                var file = this.files[0];
//                formData.append('fileUpload', file);
                fileUpload.next("span.messageErrors").remove();
                $.ajax({
                    type: "post",
                    url: urlCheckFile,
                    data: formData,
                    cache: false,
                    contentType: false,
//                    enctype: 'multipart/form-data',
                    processData: false,
                    success: function (result) {
                        if (result.status === false) {
                            //show error list fields
                            if (result.arrMessages !== undefined) {
                                $.each(result.arrMessages, function (elementName, arrMessagesEveryElement) {
                                    $.each(arrMessagesEveryElement, function (messageType, messageValue) {
                                        fileUpload.after('<span class="messageErrors" style="color:red"><br>' + messageValue + '</span>');
                                    });
                                });
                                $("button[type=submit]").attr('disabled', true);
                            }
                        }
                        // nếu k tìm thấy thẻ class messageErrors => hết lỗi ở các input file. cho submit
                        if ($("form#evaluation-form").find(".messageErrors").html() === undefined) {
                            $("button[type=submit]").removeAttr('disabled');
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>