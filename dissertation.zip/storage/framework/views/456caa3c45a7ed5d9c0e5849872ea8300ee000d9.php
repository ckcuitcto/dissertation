<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('template/css/main.css')); ?>">
    
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(URL::asset('css/bootstrap-datepicker.css')); ?>" rel="stylesheet"/>
    <link rel="shortcut icon" href="<?php echo e(url('icon/logoSTU.ico')); ?>">

    <title>STU - <?php echo $__env->yieldContent('title'); ?></title>
    <style>
        td.detail-evaluation-form {
            padding: 0px;
        }
    </style>
</head>
<body class="app sidebar-mini rtl">
<?php $__env->startSection('header'); ?>
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('menuLeft'); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php $__env->startSection('javascript'); ?>

<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('sub-javascript'); ?>
<?php echo $__env->yieldSection(); ?>

</body>
</html>