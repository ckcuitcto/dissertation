@component('mail::message')
{{ $content }}

@endcomponent